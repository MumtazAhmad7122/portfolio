tsParticles.load("tsparticles", {
  particles: { number: { value: 60 }, color: { value: "#0f6db6" }, shape: { type: "circle" },
  opacity: { value: 0.5 }, size: { value: 3 }, move: { enable: true, speed: 1 },
  links: { enable: true, color: "#0f6db6", opacity: 0.4 } }
});

// Counter Animation
const counters = document.querySelectorAll('.counter-number');
counters.forEach(counter => {
  counter.innerText = '0';
  const updateCounter = () => {
    const target = +counter.getAttribute('data-target');
    const c = +counter.innerText;
    const increment = target / 100;
    if (c < target) { counter.innerText = Math.ceil(c + increment); setTimeout(updateCounter, 50); }
    else { counter.innerText = target; }
  };
  updateCounter();
});

// Portfolio Filter
const buttons = document.querySelectorAll('.tab-btn');
const cards = document.querySelectorAll('.project-card');
buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const category = btn.getAttribute('data-category');
    cards.forEach(card => {
      if (category === 'all' || card.dataset.category.includes(category)) {
        card.style.display = 'block';
      } else {
        card.style.display = 'none';
      }
    });
  });
});